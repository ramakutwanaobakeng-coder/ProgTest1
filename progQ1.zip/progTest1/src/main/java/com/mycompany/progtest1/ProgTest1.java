/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.progtest1;

/**
 *
 * @author Student
 */
import java.util.HashMap;
public class ProgTest1 {

    public static void main(String[] args, int monthlysales) {
        Map<String, Map<String, Integer>> salesData = new HashMap<>();
        
    Map<String, Integer> CapeTownSales = new HashMap<>();
    CapeTownSales.put("coffee", 500);
    CapeTownSales.put("Tea", 300);
    CapeTownSales.put("Boba Tea", 125);
    salesData.put("CapeTown", CapeTownSales);
   
    Map<String, Integer> PESales = new HashMap<>();
    PESales.put("coffee", 450);
    PESales.put("Tea", 250);
    PESales.put("Boba Tea", 100);
    salesData.put("Port Elizabeth", PESales);
    
    Map<String, Integer> PretoriaSales = new HashMap<>();
    PretoriaSales.put("coffee", 480);
    PretoriaSales.put("Tea", 175);
    PretoriaSales.put("Boba Tea", 120);
    salesData.put("Pretoria", PESales);
    printSalesReport(salesData);
    }
public static void printSalesReport(Map<String, Map<String, Integer>> salesData) {
    System.out.println("          COFFEE HUT - MONTHLY SALES REPORT       ");
    System.out.println("%-15s %-15s %-15s\\n\", \"City\", \"Beverage\", \"Monthly Sales\" ");
    
    for (Map.Entry<String, Map<String, Integer>> cityEntry : salesData.entrySet()) {
            String city = cityEntry.getKey();
            Map<String, Integer> beverages = cityEntry.getValue();
            
            boolean isFirstRow = true;
            for (Map.Entry<String, Integer> beverageEntry : beverages.entrySet()) {
                String beverage = beverageEntry.getKey();
                int sales = beverageEntry.getValue();
                if (isFirstRow) {
                    System.out.printf("%-15s %-15s %-15d\n", city, beverage, sales);
                    isFirstRow = false;
                } else {
                    System.out.printf("%-15s %-15s %-15d\n", "", beverage, sales);
                }
            }
    }
}
}

