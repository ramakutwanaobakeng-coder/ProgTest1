/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.progq2;

/**
 *
 * @author Student
 */
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class progq2 {

    public static void main(String[] args) {
        int [][] TotalSales = { {500, 300, 125},
            {450, 250, 100},
            {480, 175, 120} };
        String entry;
        String beveragetype;
        String city;
        int TotalSales;
        entry = JOptionPane.showInputDialog(null, "Select Beverage Type");
        beveragetype = String.  (entry);
        
        }
        }
    }